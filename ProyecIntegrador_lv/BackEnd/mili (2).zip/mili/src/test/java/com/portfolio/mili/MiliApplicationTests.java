package com.portfolio.mili;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiliApplicationTests {

	@Test
	void contextLoads() {
	}

}
